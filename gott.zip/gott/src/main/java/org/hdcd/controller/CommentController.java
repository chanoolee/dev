package org.hdcd.controller;

import java.util.List;

import org.hdcd.domain.Comment;
import org.hdcd.service.CommentService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/comment")
public class CommentController {
	
	private final CommentService service;
	

	    public CommentController(CommentService service) {
	        this.service = service;
	    }
	
	@ResponseBody
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public List<Comment> list() throws Exception {
		
		List<Comment> commentList = service.list();
		System.out.println("commentList" + commentList.toString());
		
		return commentList;
	}
	
	@RequestMapping(value = "/addComment", method = RequestMethod.POST)
	@ResponseBody
	@PreAuthorize("hasRole('MEMBER')")
	public void addComment(@RequestParam Comment comment, RedirectAttributes rttr, Long boardNo) throws Exception {
		
		service.addComment(comment);
		
		System.out.println("commentId = " + comment.getUserId());
		System.out.println("commentContent = " + comment.getCommContent());
		
	}
	

}
